﻿#pragma once
int isvalid(int &a,int &b) {
	return 0;
}